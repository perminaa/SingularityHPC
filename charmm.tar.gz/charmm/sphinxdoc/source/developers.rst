:orphan:

.. _developers:

Developer Contact List
======================

This serves as a central place to accumulate developer contact information that
can be referenced from for point of contact information.


.. _developers-brb:

Bernie Brooks
-------------

  * **Location:** LCB, NIH
  * **Email:** brb@nih.gov


.. _developers-clb:

Charles Brooks
--------------

  * **Location:** University of Michigan
  * **Email:** brookscl@umich.edu


.. _developers-mc:

Mike Crowley
------------

  * **Location:** NREL
  * **Email:** michael.crowley@nrel.gov


.. _developers-mh:

Milan Hodoscek
--------------

  * **Location:** National Institute of Chemistry, Slovenia
  * **Email::** milan@cmm.ki.si


.. _developers-aph:

Antti-Pekka Hynninen
--------------------

  * **Location:** NREL
  * **Email:** antti.pekka.hynninen@nrel.gov


.. _developers-adm:

Alexander MacKerell
-------------------

  * **Location:** University of Maryland
  * **Email:** amackere@rx.umaryland.edu


.. _developers-btm:

Benjamin T. Miller
------------------

  * **Location:** LCB, NIH
  * **Email:** btmiller@nhlbi.nih.gov


.. _developers-ln:

Lennart Nilsson
---------------

  * **Location:** Karolinska Institutet, Sweden
  * **Email:** lennart.nilsson@biosci.ki.se


.. _developers-vo:

Victor Ovchinnikov
------------------

  * **Location:** Harvard
  * **Email:** ovchinnv@gmx.com


.. _developers-rjp:

Robert Petrella
---------------

  * **Location:** Harvard
  * **Email:** petrella@fas.harvard.edu


.. _developers-fcp:

Frank Pickard
-------------

  * **Location:** LCB, NIH
  * **Email:** pickard81@gmail.com


.. _developers-acs:

Andy Simmonett
--------------

  * **Location:** LCB, NIH
  * **Email:** andy.simmonett@gmail.com


.. _developers-hlw:

Lee Woodcock
------------

  * **Location:** University of South Florida
  * **Email:** hlw@mail.usf.edu


.. _developers-rmv:

Rick Venable
------------

  * **Location:** LCB, NIH
  * **Email:** venabler@nhlbi.nih.gov

