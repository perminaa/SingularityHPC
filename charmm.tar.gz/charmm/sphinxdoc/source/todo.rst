:orphan:

.. _todo:

TODO
====

::

                     /---------\           
                    /           \          
                   /             \         
                  /               \        
                  !  XXXX   XXXX  !        
                  !  XXXX   XXXX  !        
                  !  XXX     XXX  !        
                  !       X       !        
                   --\   XXX   /--         
                    ! !  XXX  ! !          
                    ! !       ! !          
                    ! I I I I I !          
                    !  I I I I  !          
                     \         /           
                      --     --            
                        \---/              
                 XXX             XXX       
                XXXX             XXXX      
                XXXXX           XXXXX      
                   XXX         XXX         
                     XXX     XXX           
                        XXXXX              
                       XXX XXX             
                     XXX     XXX           
                   XXX         XXX         
                XXXXX           XXXXX      
                XXXX             XXXX      
                 XXX             XXX       

.. todolist::
