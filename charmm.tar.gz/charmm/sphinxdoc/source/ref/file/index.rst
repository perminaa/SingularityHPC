.. _ref-file-index:

File Formats
============

.. toctree::

   rtf
   prm
   psf
   crd
   pdb
   trj

