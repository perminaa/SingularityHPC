.. index:: CRD, cor, coor, coord, coordinate, coordinates

.. _ref-file-crd:

Coordinate File
===============
