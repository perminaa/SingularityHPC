.. index:: PRM, parm, parameter, parameters

.. _ref-file-prm:

Parameter File
==============


