.. _usr-script-flow:

Flow Control
------------

Guide to writing logical tests, loops and general flow control in CHARMM input scripts.
