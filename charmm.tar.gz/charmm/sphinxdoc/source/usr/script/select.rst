.. _usr-script-select:

Atom Selection
--------------
