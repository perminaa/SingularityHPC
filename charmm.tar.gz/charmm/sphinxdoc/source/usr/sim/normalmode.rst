.. _usr-sim-normalmode:

Normal Mode Analysis
====================

Documentation assigned to :ref:`developers-brb`.
