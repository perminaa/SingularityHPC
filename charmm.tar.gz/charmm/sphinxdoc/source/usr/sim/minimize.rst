.. _usr-sim:

Minimization
============

Should be done before dynamics
