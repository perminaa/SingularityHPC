.. _usr-model-cg-go:

Go Models
=========

Even more flavors of these.
