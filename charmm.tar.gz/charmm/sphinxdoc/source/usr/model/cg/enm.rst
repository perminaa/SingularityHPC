.. _usr-model-cg-enm:

Elastic Network Model
=====================

There are several flavors of these.
