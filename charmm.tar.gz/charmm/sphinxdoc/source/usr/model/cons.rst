.. _usr-model-cons:

Constraints & Restraints
========================

What's the difference?

When should I use constraints?
------------------------------

When should I use restraints?
-----------------------------
