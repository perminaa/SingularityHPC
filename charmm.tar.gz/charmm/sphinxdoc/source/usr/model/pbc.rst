. _usr-model-pbc:

Periodic Boundary Conditions
============================

Choose the crystal shape
------------------------

Apply the symmetry operations
-----------------------------

Minimum Image Convention
------------------------
