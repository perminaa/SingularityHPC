.. _usr-adv-fe-index:

Free Energy Calculations
========================

.. toctree::

   nbb

**Possible Approaches:**

Certain topics of interest to many members of the CHARMM community will
probably be controversial when documenting "best practices" for these topics,
we could have a listing of different approaches advocated by different members
of the community or we could do a breakdown by submethod, or both, or something
else completely.
