.. index:: Leapfrog, Verlet, Integrators

.. _con-integrators:

Integrators
===========

A description of the theory underlying the different integrators.

.. todo:: This page is to be completed by :ref:`developers-brb`.

