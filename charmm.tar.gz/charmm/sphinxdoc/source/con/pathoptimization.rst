.. index:: Path Optimization, Minimization

.. _con-pathoptimization:

Path Optimization
=================

Overview of the theory here.

.. todo:: This page is to be completed by :ref:`developers-vo`.

