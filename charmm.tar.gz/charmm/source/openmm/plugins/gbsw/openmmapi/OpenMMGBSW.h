#ifndef OPENMM_GBSW_H_
#define OPENMM_GBSW_H_

/* -------------------------------------------------------------------------- *
 *                               OpenMMGBSW                                   *
 * -------------------------------------------------------------------------- */

#include "GBSWForce.h"

#endif /*OPENMM_GBWS_H_*/
