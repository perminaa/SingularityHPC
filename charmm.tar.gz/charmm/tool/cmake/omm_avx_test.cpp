#include <iostream>
#include <openmm/internal/vectorize.h>

int main() {
  std::cout << "Hi there!" << std::endl;
}


