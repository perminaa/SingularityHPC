#include <iostream>
#include <openmm/internal/ThreadPool.h>

int main() {
  std::cout << "Hi there!" << std::endl;
}


